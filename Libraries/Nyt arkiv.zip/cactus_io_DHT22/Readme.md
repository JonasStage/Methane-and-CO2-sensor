This is an Arduino library for the DHT22 temperature/humidity sensors. 
